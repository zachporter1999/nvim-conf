--[[
-- startify.lua
-- by: Zach Porter
--]]

vim.api.nvim_set_keymap('n', '<leader>h', ':Startify<cr>', {noremap = true})
