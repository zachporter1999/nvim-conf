--[[
-- which-key.lua
-- by: Zach Porter
--]]

local wk = require("which-key")
wk.register({}, { prefix = "<leader>"})
